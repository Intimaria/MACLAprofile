# lido-profile

Spanish translation of libis ([?](https://librarytechnology.org/libraries/search.pl?Consortia=LIBIS)) [LIDO](http://www.lido-schema.org) [profile](https://docs.collectiveaccess.org/wiki/Installation_profile) for [Collective Access](https://collectiveaccess.org/).

Using [current profile.xsd](https://github.com/collectiveaccess/providence/blob/master/install/profiles/xml/profile.xsd).

## Reference

- [Current official profiles](https://github.com/collectiveaccess/providence/tree/master/install/profiles/xml)
